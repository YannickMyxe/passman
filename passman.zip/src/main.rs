#[macro_use]
extern crate magic_crypt;

use std::{
    fs::File,
    io::{BufReader, Read, Write, BufRead}
};

use magic_crypt::MagicCryptTrait;

fn main() {
    let password: String = String::from("string to encrypt");

    let filepath = String::from("./passman.txt");
    match add_password(&filepath, &String::from("google.com"), &encrypt(&password)) {
        Ok(resp) => println!("Written to file with. New Length: {}", resp),
        Err(err) => eprintln!("Could not write to file! {}", err),
    }

    match get_passwords_vector(&filepath) {
        Ok(vector) => {
            for (index, value) in vector.iter().enumerate() {
                println!("Succesfull vecotor gotten! [{}] ==> {}", index, value);
            }
        },
        Err(err) => {
            println!("Error on trying to get password vec: {}", &err)
        },
    };

}

fn encrypt(password: &String) -> String {
    let mcrypt = new_magic_crypt!("magickey", 256); //Creates an instance of the magic crypt library/crate.
    mcrypt.encrypt_str_to_base64(password)
}

fn _decrypt(encrypted: &String) -> String {
    let mcrypt = new_magic_crypt!("magickey", 256); //Creates an instance of the magic crypt library/crate.
                                                    //Decrypts the string so we can read it.
    match mcrypt.decrypt_base64_to_string(encrypted) {
        Ok(value) => {value},
        Err(err) => {err.to_string()},
    }
}

fn _open_file_or_create(filepath: &String) -> std::io::Result<File> {
    match File::open(filepath) {
        Ok(file) => Ok(file),
        Err(_) => File::create(filepath),
    }
}

fn read_file(filepath: &String) -> std::io::Result<String> {
    let file = File::open(filepath)?;
    let mut buf_reader = BufReader::new(file);
    let mut contents = String::new();
    buf_reader.read_to_string(&mut contents)?;
    Ok(contents)
}

fn _write_file(filepath: &String, content: &String) -> Result<usize, std::io::Error> {
    let mut file = File::create(filepath)?;
    let buf = content.as_bytes();
    file.write(buf)
}

fn _append_file(filepath: &String, content: &String) -> Result<usize, std::io::Error> {
    let file_content = read_file(filepath)?;
    let mut file = File::create(filepath)?;
    let wr = file_content + content + &String::from("\n");
    let buf = wr.as_bytes();
    file.write(buf)
}

fn add_password(filepath: &String, adress: &String, password: &String) -> Result<usize, std::io::Error> {
    let file_content = match read_file(filepath) {
        Ok(value) => value,
        Err(_) => {
            println!("Created file: {}", filepath);
            String::from("")    
        },
    };
    let comma = if file_content != "" { ", \n" } else { "" };
    let mut file = File::create(filepath)?;
    let wr = file_content + comma + "{ \"" + adress + "\" : \"" + password + &String::from("\" }");
    let buf = wr.as_bytes();
    file.write(buf)
}

fn _get_passwords_string(filepath: &String) -> String {
    match read_file(filepath) {
        Ok(value) => value,
        Err(err) => {
            println!("Error: {}", err);
            String::from("")    
        },
    }
}

fn get_passwords_vector (filepath: &String) -> Result<Vec<String>, std::io::Error> {
    let f_result = File::open(filepath);
    match f_result {
        Ok(file) => {
            BufReader::new(file).lines().collect()
        },
        Err(err) => {
            println!("Failed to open file! {}", err);
            Err(err)
        },
    }

}